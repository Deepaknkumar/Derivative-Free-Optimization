function[fy] = function9_9(Y)
fy = sin(Y.^2) + sqrt(Y);
% fy = Y.^3;
fy = fy';
end